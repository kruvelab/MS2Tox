How to run the calulations

1. Install anaconda3
2. Create folder 'conf_pred' and go to the created folder
3. Create conda environment 'cp' by command: conda env create --name cp --file cp.yml
######## NOTE that scikit-learn version 1.1.3 is important for nonconformist 1.2.5. Later versions of scikit-learn may not be compatible with nonconformist a produce spurious results.
4. In folder 'conf_pred' untar the tarball: tar xvf CP_code.tar.gz
5. For each training and test file: run the folowing commands in order:

conda activate cp
python conformal_prediction_cvX_column_select.py -c 10 -s t -i <training_data_file>  #cross-validation of training set
python conformal_prediction.py -n 10 -m b -s t -i <training_data_file> -p  <test_data_file>
python val_eff2.py <test_data_file>_nonconf_pred10sum.csv -1 0
python calculate_performance_from_val_eff2a.py <test_data_file>_nonconf_pred10sum.csv.val_eff_10.0 -1
python val_eff2.py <training_data_file>_nonconf_pred_cv10_sum.csv -1 0
python calculate_performance_from_val_eff2a.py <training_data_file>_nonconf_pred_cv10_sum.csv.val_eff_10.0 -1
