#!/usr/bin/env python

"""
MIT License

Copyright (c) 2024 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import pandas as pd
import os,sys
import math
import numpy as np

from sklearn.metrics import precision_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import matthews_corrcoef
from sklearn.metrics import f1_score
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import balanced_accuracy_score
from sklearn.metrics import accuracy_score


def stats(TN,FP,FN,TP,nrows, BE1, BE0):

    CoverageP = (TP + FN)/(TP + FN + BE1)
    CoverageN = (TN + FP)/(TN + FP + BE0)

    d1 = TP+FN
    sensitivity = TP/d1 if d1 != 0 else 0
    d2 = TN+FP
    specificity = TN/d2 if d2 != 0 else 0

    precision = TP/(TP+FP)

    f1 = (2*precision*sensitivity/(precision + sensitivity))

    FPR = FP/(FP+TN)
    mFPR = FP/(FP+TN+BE0)

    TPR = TP/(TP+FN)
    mTPR = TP/(TP+FN+BE1)

    output_file = sys.argv[1] +'_performance.csv'

    if nrows < 3:
        f= open(output_file , mode='w')
        aaa = "File,precision,f1_score_val,ROC_AUC_score,FPR_score,TPR_score,mFPR_score,mTPR_score,CoverageP,CoverageN\n"
        f.write(aaa)
        aaa = output_file  + "," + str(format(round(precision,4))) + "," + str(format(round(f1,4))) + "," + "-99.0" + "," + str(format(round(FPR,4))) + "," + str(format(round(TPR,4))) + "," + str(format(round(mFPR,4))) + "," + str(format(round(mTPR,4))) + "," + str(format(round(CoverageP,4)))  + "," + str(format(round(CoverageN,4))) + "\n"
        print (aaa)
        f.write(aaa)
        f.close()
    if nrows > 2:
        f= open(output_file , mode='a')
        aaa = output_file  + "," + str(format(round(precision,4))) + "," + str(format(round(f1,4))) + "," + "-99.0" + "," + str(format(round(FPR,4))) + "," + str(format(round(TPR,4))) + "," + str(format(round(mFPR,4))) + "," + str(format(round(mTPR,4))) + "," + str(format(round(CoverageP,4)))  + "," + str(format(round(CoverageN,4))) + "\n"
        f.write(aaa)

    f.close()

    print("Metrics in file:", output_file)



################ main ################ 

try:
    sys.argv[1]
except IndexError:
    print ("You need to specify a val_eff2 space separated summary val_eff2 file")
    sys.exit(1)

try:
    sys.argv[2]
except IndexError:
    print ("You need to specify sign.level (0 for first row, <0 for all rows, sign.level for sign.level only")
    sys.exit(1)

signlevel = float(sys.argv[2])

df = pd.read_csv(sys.argv[1], header=0, index_col = None, sep=' ')
df['sig_lvls'] = df['sig_lvls']
print (df)

try:
    TN = df['correct0'].values.astype(float)
except:
    try:
        TN = df['corr0'].values.astype(float)
    except:
        TN = 'nan'

try:
    FP = df['incorrect0'].values.astype(float)
except:
    try:
        FP = df['incorr0'].values.astype(float)
    except:
        FP = 'nan'

try:
    FN = df['incorrect1'].values.astype(float)
except:
    try:
        FN = df['incorr1'].values.astype(float)
    except:
        FN = 'nan'

try:
    TP = df['correct1'].values.astype(float)
except:
    try:
        TP = df['corr1'].values.astype(float)
    except:
        TP = 'nan'


try:
    B1 = df['both1'].values.astype(float)
except:
    try:
        B1 = df['both1'].values.astype(float)
    except:
        B1 = 'nan'

try:
    E1 = df['empty1'].values.astype(float)
except:
    try:
        E1 = df['empty1'].values.astype(float)
    except:
        E1 = 'nan'

try:
    B0 = df['both0'].values.astype(float)
except:
    try:
        B0 = df['both0'].values.astype(float)
    except:
        B0 = 'nan'
try:
    E0 = df['empty0'].values.astype(float)
except:
    try:
        E0 = df['empty0'].values.astype(float)
    except:
        E0 = 'nan'



nrows = 1

print (signlevel)
if signlevel > 0.0:
    signlevels = df['sig_lvls'].values
    idx = np.where(signlevels == signlevel)[0][0]
    print (signlevels, idx)
    TN = TN[idx]
    FP = FP[idx]
    FN = FN[idx]
    TP = TP[idx]

    BE1 = E1[idx] + B1[idx] 
    BE0 = E0[idx] + B0[idx] 

    signlevel = df['sig_lvls'].values
    signlevel = signlevel[idx]

    print ("1 FP, FN, TN, TP, BE1, BE0", FP, FN, TN, TP, BE1, BE0)
    stats(TN,FP,FN,TP,nrows, BE1, BE0)
    
if signlevel == 0.0:
    TN = TN[0]
    FP = FP[0]
    FN = FN[0]
    TP = TP[0]

    BE1 = E1[0] + B1[0] 
    BE0 = E0[0] + B0[0] 

    signlevel = df['sig_lvls'].values
    signlevel = signlevel[0]

    print ("2 FP, FN, TN, TP, BE1, BE0", FP, FN, TN, TP, BE1, BE0)
    stats(TN,FP,FN,TP,nrows, BE1, BE0)

print (TN)

if signlevel < 0.0:
    signlevels = df['sig_lvls'].values
    TN0 = TN
    FP0 = FP
    FN0 = FN
    TP0 = TP

    E00 = E0
    E10 = E1
    B00 = B0
    B10 = B1

    nrows = 2
    for idx0 in signlevels:
        idx = np.where(signlevels == idx0)[0][0]
        print (signlevels, idx, idx0)
        print (TN)
        TN = TN0[idx]
        FP = FP0[idx]
        FN = FN0[idx]
        TP = TP0[idx]

        BE1 = E10[idx] + B10[idx] 
        BE0 = E00[idx] + B00[idx] 

        signlevel = signlevels[idx]

        print ("3 FP, FN, TN, TP, BE1, BE0", FP, FN, TN, TP, BE1, BE0)
        stats(TN,FP,FN,TP,nrows, BE1, BE0)
        nrows = nrows + 1
