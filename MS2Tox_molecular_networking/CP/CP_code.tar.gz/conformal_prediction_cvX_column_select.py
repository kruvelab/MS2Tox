#!/usr/bin/env python

"""
MIT License

Copyright (c) 2024 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

 
def writeOutListsApp(filePath, dataLists, delimiter = '\t'):
    with open(filePath, 'a') as fd:
        numOfLists = len(dataLists)
        lenOfLists = len(dataLists[0])
        for lineNum in range(lenOfLists):
            tmpString = ""
            for column in range(numOfLists):
                tmpString += str(dataLists[column][lineNum]) + delimiter
            fd.write(tmpString.strip() + "\n")


import os,sys
from sklearn.ensemble import RandomForestClassifier
from nonconformist.icp import IcpClassifier
from nonconformist.nc import ProbEstClassifierNc, margin
import pandas as pd
import numpy as np
from argparse import ArgumentParser
from sklearn.utils import shuffle
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
import random
from sklearn.utils import shuffle

parser = ArgumentParser()
parser.add_argument('-i','--infile', help='input training file')
parser.add_argument('-c','--cv', type=str, help='number of cv folds (default 5 folds)')
parser.add_argument('-s','--sep', type=str, choices=['t','c'], help='file separator: tab or comma')
args = parser.parse_args()

infile = args.infile
cv = args.cv
sep = args.sep

if infile == None or sep == None:
    parser.print_help(sys.stderr)
    sys.exit(1)

if cv == None:
    cv = 5
cv = int(cv)


if sep == 't':
    data = pd.read_csv(infile, sep='\t', header = 0, index_col = None)
if sep == 'c':
    data = pd.read_csv(infile, sep=',', header = 0, index_col = None)

try:
    labels = data['id'].values
except:
    data.rename(columns={ data.columns[0]: "id" }, inplace = True)
    labels = data['id'].values
    print("/////////////////////// renaming column 1 to 'id' ///////////////////////")



if 'class' in data.columns:
    data.rename(columns={'class': 'target'}, inplace=True)

try:
    data.loc[data['target'] < 0, 'target'] = 0
except:
    data.rename(columns={ data.columns[1]: "target" }, inplace = True)
    data.loc[data['target'] < 0, 'target'] = 0
    print("/////////////////////// renaming column 2 to 'target' ///////////////////////")
    print (data)

labels = data['id']
print (labels)
idlist = labels.unique()
print (idlist)
cls_uniq = data['target'].nunique()
print("Number of classes:",cls_uniq)
data = data.drop(['dataset'], axis=1, errors='ignore')
data.replace([np.inf, -np.inf], np.nan, inplace=True)
cols = (np.arange(3, data.shape[1]-1))
nancount = data.iloc[:,cols].isnull().sum().sum()

if nancount > 0:
    print ("imputing missing values:",nancount)
    imp = SimpleImputer(missing_values=np.nan, strategy='mean')
    impmodel = imp.fit(data.iloc[:,cols])
    data.iloc[:,cols] = impmodel.transform(data.iloc[:,cols])


SEED = 1234
idlist = shuffle(idlist, random_state=SEED)
skf = KFold(n_splits=cv)
skf.get_n_splits(idlist)
print ("shuffled idlist")
print (idlist)

xx = 0
outfile = infile + "_nonconf_pred_cv" + str(cv) + "_sum.csv"
f2 = open(outfile,'w')
if cls_uniq > 2:
	f2.write('id\tp-value_low_class\tp-value_high_class\tp-value_highest_class\tclass\tmodel\n')
else:
    f2.write('id\tp-value_low_class\tp-value_high_class\tclass\tmodel\n')
f2.close()

data2 = data
for train_index, test_index in skf.split(idlist):
    data = data2
    print(train_index, test_index)
    trainset, testset = idlist[train_index], idlist[test_index]
#    print ("trainset")
#    print (trainset)

#    dftest = data[data['id'].isin(testset)]
#    print ("testnset")
#    print (testset)
    data = data.drop(columns=testset)
    print (data.shape)    
    print (data2.shape)
    print (len(testset))

    for loop in range(0,2000):
        trainset2, calset = train_test_split(trainset, test_size=0.3)
#        print (calset)
 
        dftrain = data[data['id'].isin(trainset2)]
        train_uniq = dftrain['target'].nunique()
        dfcal = data[data['id'].isin(calset)]
        cal_uniq = dfcal['target'].nunique()
        if train_uniq > 1 and cal_uniq > 1:
            break

    if train_uniq < 2:
        print("/////////////////////// training set contains only one class - stopping ///////////////////////")
        sys.exit(1)
    if cal_uniq < 2:
        print("/////////////////////// calibration set contains only one class - stopping ///////////////////////")
        sys.exit(1)


    xx = xx + 1
    print (" Working on loop", xx)

    targettrain = dftrain['target'].values
    train = dftrain.drop(columns=['id', 'target'], axis=1, errors='ignore').values
    targetcal = dfcal['target'].values
    calibr = dfcal.drop(columns=['id', 'target'], axis=1, errors='ignore').values
    del dftrain, dfcal

    nc = ProbEstClassifierNc(RandomForestClassifier,margin,model_params={'n_estimators': 100})
    icp_norm = IcpClassifier(nc, condition=lambda instance: instance[1])
    icp_norm.fit(train, targettrain)
    icp_norm.calibrate(calibr, targetcal)

    dftest = data[data['id'].isin(testset)]
    test_uniq = dftest['target'].nunique()
    print("unique classes, train, cal, test:", train_uniq, cal_uniq, test_uniq)
    labels = dftest['id'].values
    ll = len(labels)
    num = [xx]*ll
    targettest = dftest['target'].values
    print (targettest)
    test = dftest.drop(columns=['id', 'target'], axis=1, errors='ignore').values

    print ("\r Predicting from model", xx, end='')
    predicted = icp_norm.predict(test)
    print ("predicted raw output")
    print (predicted)
    print (labels, targettest, predicted,num)
    predicted0 = [x[0] for x in predicted]
    predicted1 = [x[1] for x in predicted]
    if cls_uniq > 2:
        predicted2 = [x[2] for x in predicted]
        writeOutListsApp(outfile, [labels, predicted0,  predicted1,  predicted2, targettest, num])
    else:
        writeOutListsApp(outfile, [labels, predicted0,  predicted1, targettest, num])

print (" - finished\n")

